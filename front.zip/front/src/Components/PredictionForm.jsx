import React, { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";

const PredictionForm = () => {
  const [direction, setDirection] = useState("up");
  const [amount, setAmount] = useState("");
  const [deliveryTime, setDeliveryTime] = useState(60);
  const [predictionId, setPredictionId] = useState(null);
  const [result, setResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [interest, setInterest] = useState(0); // State to hold interest rate

  const location = useLocation();
  const navigate = useNavigate();
  const { state } = location || {};
  const { value } = state || {};
  const walletAddress = localStorage.getItem("walletAddress");

  // Delivery times with interest rates and minimum amounts
  const deliveryTimes = [
    { time: 60, interest: 0.1, minAmount: 20 },
    { time: 600, interest: 0.3, minAmount: 50 },
    { time: 3600, interest: 0.5, minAmount: 100 },
    { time: 86400, interest: 1.0, minAmount: 200 },
  ];

  // Calculate and update interest when deliveryTime changes
  useEffect(() => {
    const selectedTime = deliveryTimes.find(
      (dt) => dt.time === Number(deliveryTime)
    );
    if (selectedTime) {
      setInterest(selectedTime.interest);
    }
  }, [deliveryTime]);

  // Effect to handle submitting prediction and fetching result
  useEffect(() => {
    if (predictionId) {
      const interval = setInterval(async () => {
        try {
          const response = await axios.get(
            `http://localhost:5000/api/prediction/${predictionId}`
          );
          if (response.data) {
            setResult(response.data);
            clearInterval(interval); // Stop checking after getting the result
          }
        } catch (error) {
          console.error("Error fetching prediction result:", error);
        }
      }, 5000); // Check every 5 seconds

      return () => clearInterval(interval);
    }
  }, [predictionId]);

  // Function to handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const userId = localStorage.getItem("userId");
    const walletAddress = localStorage.getItem("walletAddress");

    try {
      const priceResponse = await axios.get(
        "https://api.coingecko.com/api/v3/coins/markets",
        {
          params: {
            vs_currency: "usd",
            ids: value.id,
            order: "market_cap_desc",
            per_page: 1,
            page: 1,
            sparkline: false,
          },
        }
      );
      const currentPrice = priceResponse.data[0].current_price;

      const response = await axios.post("http://localhost:5000/api/predict", {
        symbol: value.id,
        direction,
        amount: Number(amount),
        deliveryTime,
        currentPrice,
        userId,
        walletAddress,
      });
      setPredictionId(response.data._id);
    } catch (error) {
      console.error("Error submitting prediction:", error);
      if (error.response && error.response.data && error.response.data.error) {
        alert(error.response.data.error); // Display the error message
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Function to close the modal
  const closeModal = () => setShowModal(false);

  // Function to open the modal
  const openModal = () => setShowModal(true);

  // TradingView Widget
  const onLoadScriptRef = useRef();

  useEffect(() => {
    onLoadScriptRef.current = createWidget;

    if (!window.tvScriptLoadingPromise) {
      window.tvScriptLoadingPromise = new Promise((resolve) => {
        const script = document.createElement("script");
        script.id = "tradingview-widget-loading-script";
        script.src = "https://s3.tradingview.com/tv.js";
        script.type = "text/javascript";
        script.onload = resolve;

        document.head.appendChild(script);
      });
    }

    window.tvScriptLoadingPromise.then(
      () => onLoadScriptRef.current && onLoadScriptRef.current()
    );

    return () => (onLoadScriptRef.current = null);

    function createWidget() {
      if (
        document.getElementById("tradingview_17e74") &&
        "TradingView" in window
      ) {
        new window.TradingView.widget({
          autosize: true,
          symbol: "BITSTAMP:" + `${value.symbol}` + "USD",
          interval: "D",
          timezone: "Asia/Kolkata",
          theme: "dark",
          style: "1",
          locale: "in",
          toolbar_bg: "#f1f3f6",
          enable_publishing: true,
          hide_legend: true,
          withdateranges: true,
          save_image: true,
          details: true,
          calendar: false,
          container_id: "tradingview_17e74",
        });
      }
    }
  }, [value]);

  // Retrieve selected delivery time details
  const selectedTime = deliveryTimes.find(
    (dt) => dt.time === Number(deliveryTime)
  );

  return (
    <div className="pt-[100px] bg-[#171b26] min-h-screen">
      <div className="tradingview-widget-container">
        <div
          id="tradingview_17e74"
          className="h-[500px] w-[90%] mx-auto pt-10"
        />
      </div>
      <div className="w-[100px] grad_bg blur-[220px] right-[10px] h-[100px] absolute border-2 rounded-full"></div>
      <div
        className="w-[70%] mx-auto bg-[#1b202d] p-6 items-center"
        style={{ color: "white" }}
      >
        <div className="mb-4">
          <p>Wallet Address: {walletAddress}</p>
        </div>
        <button
          className="bg-orange-500 hover:bg-orange-700 text-white font-bold py-2 px-4 rounded mb-4"
          onClick={openModal}
        >
          Make a Prediction for {value?.name}
        </button>
      </div>

      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-[#1b202d] p-6 rounded-lg">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl text-white">{value?.name} Delivery</h2>
              <span
                className="text-white text-5xl cursor-pointer"
                onClick={closeModal}
              >
                &times;
              </span>
            </div>
            <div
              style={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
                textAlign: "center",
                alignItems: "center",
              }}
            >
              {value?.image && (
                <img
                  src={value.image}
                  alt={value?.name}
                  className="w-20 h-20 mt-2 mb-6"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src =
                      "https://via.placeholder.com/150?text=No+Image";
                  }}
                />
              )}
            </div>
            <div className="mb-4">
              <h3 style={{ color: "white" }}>
                Wallet Address: {walletAddress}
              </h3>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-white">
                    Delivery Time
                  </label>
                  <select
                    value={deliveryTime}
                    onChange={(e) => setDeliveryTime(Number(e.target.value))}
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    {deliveryTimes.map((dt) => (
                      <option key={dt.time} value={dt.time}>
                        {dt.time} seconds
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-white">
                    Direction
                  </label>
                  <select
                    value={direction}
                    onChange={(e) =>
                      setDirection(e.target.value === "Bullish" ? "up" : "down")
                    }
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  >
                    <option value="Bullish">Bullish</option>
                    <option value="Bearish">Bearish</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-white">
                    Amount
                  </label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => {
                      const value = e.target.value;
                      setAmount(value === "" ? "" : Number(value));
                    }}
                    className="mt-1 block w-full pl-3 pr-3 py-2 border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                  />
                </div>
              </div>
              <div className="mt-4">
                <p className="text-white">Fee: {amount * 0.001} USD</p>
                <p className="text-white">
                  Minimum Amount: {selectedTime?.minAmount} USD
                </p>
                <p className="text-white">
                  Interest Rate: {interest * 100}% per transaction
                </p>
              </div>
              <div className="mt-4">
                <button
                  type="submit"
                  className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  disabled={isLoading}
                >
                  {isLoading ? "Submitting..." : "Submit Prediction"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionForm;
