import React, { useState } from "react";
import "./PredictionSummary.css"; // Import the CSS file

const PredictionSummary = ({ prediction, logo, showResult }) => {
  const [showDetails, setShowDetails] = useState(false);

  const handleToggleDetails = () => {
    setShowDetails(!showDetails);
  };

  const logoUrl = `https://coin-images.coingecko.com/coins/images/1/large/${prediction.symbol.toLowerCase()}.png`;

  const isProfit = prediction.result && prediction.result.success;
  const profitLossAmount = prediction.result
    ? isProfit
      ? prediction.result.profit
      : prediction.amount
    : 0;

  const profitLossClass = isProfit ? "profit" : "loss";
  const profitLossIcon = isProfit ? "↑" : "↓";
  const profitLossMessage = prediction.result
    ? isProfit
      ? `You have won ${profitLossAmount}`
      : `You have lost all your money i.e. ${profitLossAmount}`
    : "Pending";

  return (
    <div className="prediction-summary" onClick={handleToggleDetails}>
      <div className="summary-header">
        <div>
          <img
            src={logo || logoUrl}
            alt={`${prediction.symbol} logo`}
            className="logo"
            onError={(e) => {
              e.target.onerror = null;
              e.target.src = "https://via.placeholder.com/50"; // Fallback image if logo is not found
            }}
          />
          <h1>{prediction.symbol.toUpperCase()}</h1>
        </div>
        <div>
          <p>{new Date(prediction.predictedAt).toLocaleString()}</p>
          {showResult && prediction.result ? (
            <p className={`profit-loss ${profitLossClass}`}>
              {profitLossIcon}{" "}
              {isProfit ? (
                <span>{profitLossAmount}</span>
              ) : (
                <span className="loss-amount">{profitLossAmount}</span>
              )}
            </p>
          ) : (
            <p className="pending">Pending</p>
          )}
        </div>
      </div>
      {showDetails && (
        <div className="details">
          <p>Symbol: {prediction.symbol}</p>
          <p>Direction: {prediction.direction}</p>
          <p>Amount: {prediction.amount}</p>
          <p>Delivery Time: {prediction.deliveryTime}</p>
          <p>Purchased Price: {prediction.currentPrice}</p>
          <p>Fee: {prediction.fee}</p>
          <p>Result: {prediction.result ? profitLossMessage : "Pending"}</p>
        </div>
      )}
    </div>
  );
};

export default PredictionSummary;
