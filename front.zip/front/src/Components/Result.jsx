import React, { useEffect, useState } from "react";
import axios from "axios";
import PredictionSummary from "./PredictionSummary";
import Countdown from "./Countdown";
import "./Result.css"; // Importing the CSS file

const Result = () => {
  const [predictions, setPredictions] = useState([]);
  const [logos, setLogos] = useState({});
  const [selectedTab, setSelectedTab] = useState("wait");
  const userId = localStorage.getItem("userId");

  useEffect(() => {
    const fetchPredictions = async () => {
      try {
        const response = await axios.get(
          `http://localhost:5000/api/predictions/user/${userId}`
        );
        console.log("Fetched predictions:", response.data); // Log fetched data
        // Sort predictions by predictedAt in descending order
        const sortedPredictions = response.data.sort(
          (a, b) => new Date(b.predictedAt) - new Date(a.predictedAt)
        );
        setPredictions(sortedPredictions);
      } catch (error) {
        console.error("Error fetching predictions:", error);
      }
    };

    fetchPredictions();
  }, [userId]);

  useEffect(() => {
    const fetchLogos = async () => {
      try {
        const response = await axios.get(
          "https://api.coingecko.com/api/v3/coins/markets",
          {
            params: {
              vs_currency: "inr",
              order: "market_cap_desc",
              per_page: 100,
              page: 1,
              sparkline: false,
            },
          }
        );
        const logoMap = {};
        response.data.forEach((coin) => {
          logoMap[coin.symbol.toUpperCase()] = coin.image;
        });
        setLogos(logoMap);
      } catch (error) {
        console.error("Error fetching logos:", error);
      }
    };

    fetchLogos();
  }, []);

  const renderPredictions = (filterFn, showResult) =>
    predictions.filter(filterFn).map((prediction) => (
      <li key={prediction._id} className="prediction-item">
        <PredictionSummary
          prediction={prediction}
          logo={logos[prediction.symbol.toUpperCase()]}
          showResult={showResult}
        />
        {selectedTab === "wait" && (
          <p>
            Time Left:{" "}
            <Countdown
              deliveryTime={prediction.deliveryTime}
              predictedAt={prediction.predictedAt}
            />
          </p>
        )}
      </li>
    ));

  const isCountdownOver = (prediction) => {
    const timeElapsed = Math.floor(
      (Date.now() - new Date(prediction.predictedAt)) / 1000
    );
    return timeElapsed >= prediction.deliveryTime;
  };

  return (
    <div className="result-container">
      <h2 className="title">Prediction Results</h2>
      <div className="button-group">
        <button
          className={`tab-button ${selectedTab === "wait" ? "active" : ""}`}
          onClick={() => setSelectedTab("wait")}
        >
          Wait
        </button>
        <button
          className={`tab-button ${selectedTab === "finished" ? "active" : ""}`}
          onClick={() => setSelectedTab("finished")}
        >
          Finished
        </button>
      </div>
      {selectedTab === "wait" ? (
        <ul className="prediction-list">
          {predictions.filter((prediction) => !isCountdownOver(prediction))
            .length === 0 ? (
            <p className="no-predictions">
              No pending predictions found for this user.
            </p>
          ) : (
            renderPredictions(
              (prediction) => !isCountdownOver(prediction),
              false
            )
          )}
        </ul>
      ) : (
        <ul className="prediction-list">
          {predictions.filter((prediction) => isCountdownOver(prediction))
            .length === 0 ? (
            <p className="no-predictions">
              No finished predictions found for this user.
            </p>
          ) : (
            renderPredictions((prediction) => isCountdownOver(prediction), true)
          )}
        </ul>
      )}
    </div>
  );
};

export default Result;
